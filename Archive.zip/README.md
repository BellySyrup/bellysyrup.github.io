sconzen.github.io
=================

Work in progress.

Rebuilding mnmlist.com in Github Pages and Jekyll.
The Idea is to create a simple blog, hosted on Github, using templates and markdown.
I want to be able to focus on the quality on content, instead of spending more time styling and formatting text.
This method also prevents the use of wordpress which I am not to fond of.

No Database.
No Javascript.
No modifying the original CSS.
Markdown for simple post formatting.

Design and concept by Leo Babauta.

Tools used:

Sublime Text, Notepad++, Github
Jekyll + Markdown
