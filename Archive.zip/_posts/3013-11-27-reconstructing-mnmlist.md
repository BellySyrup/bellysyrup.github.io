---
layout: default
title: reconstructing mnmlist
---

### Step 1: Steal Underpants

I will document my current project, building this website in this post.  
I'll note some of the roadblocks I've faced, my solutions, and tips for anyone wanting to use this jekyll template.  
Also this is my first time using markdown, so I will post examples of the syntax used in this site.  

### Step 2: ???

### Step 3: Profit