---
layout: default
title: who am i
---

My name is Stephan Conzen   
I am 26 years old  
Quite fond of cheeseburger pizza  
Born in Neuss, Germany, live in Ontario, Canada.  

I throw code at my computer... see what happens  

### More about me:

+ [Twitter](http://twitter.com/sconzen)  
+ [Github](http://github.com/sconzen)  
+ [Dunked](http://sconzen.dunked.com)  
+ [Gmail](mailto:sconzen@gmail.com)

This site is based on [mnmlist](http://mnmlist.com), picked apart and glued back together using [jekyll](http://jekyllrb.com/).
Mnmlist is originally created by Leo Babauta, who was kind enough to give permission to go bananas on his site. Jekyll allowed me to create a simple version of the original, without the need for wordpress, or the database that would be required by wordpress to store all posts and pages.
Github Pages allowed me to use Jekyll and Markdown to easily replicate the structure needed for each page/post, without the need to modify Leos original CSS.

### Still TODO:

+ Properly group and style the post lists by date.
+ Step by step documentation on this project.
+ Actually post something.
+ Finish Pages for bottom menu.  
+ Remove [Lorem Ipsum](http://www.lipsum.com/) Content