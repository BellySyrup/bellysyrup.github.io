$(function(){
	$('img').remove();
});
