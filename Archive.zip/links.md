---
layout: default
title: links
---

### other stuff that i've done  

[color](http://sconzen.github.io/color)  
[Twitter](http://twitter.com/sconzen)  
[Twitter](http://twitter.com/sconzen)  
[Twitter](http://twitter.com/sconzen)  
[Twitter](http://twitter.com/sconzen)  